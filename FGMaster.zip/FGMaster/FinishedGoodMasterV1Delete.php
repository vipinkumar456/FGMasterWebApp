<?php
        require("Db.php");
            $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
            $conn = sqlsrv_connect($serverName, $options);
			$RecID = $_POST['RecID'];
			
            $str = "dbo.EmsNet_Proc_FinishedGoodMasterV1Web_Delete
					@RecID='".$RecID."'"
                ;
            $query = sqlsrv_query($conn,$str);
             sqlsrv_close($conn);
			 echo $str;
?>