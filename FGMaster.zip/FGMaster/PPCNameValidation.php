<?php
        require("Db.php");
            $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
            $conn = sqlsrv_connect($serverName, $options);
            $RecID = $_POST['RecID'];
			$PPCName = $_POST['PPCName'];
		
			
            $str=" dbo.[EmsNet_Proc_FinishedGoodMasterV1_PPCName_Validation]
			     @RecID ='".$RecID."',
				
				 @PPCName	='".$PPCName."'" ;	
            $query = sqlsrv_query($conn,$str);
            $row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
                if($row)
                        {
                            echo json_encode($row); 
                        }    
?>