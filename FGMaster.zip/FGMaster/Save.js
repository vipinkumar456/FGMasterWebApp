
function UpdateAgentDetails(){
                $MaterailType = document.getElementById("Modal-State").value;
                $PartName = document.getElementById("Modal-City").value;
                $PartNo = document.getElementById("Modal-PartNo").value;
                $PPCName = document.getElementById("Modal-PPCName").value;
                $Description = document.getElementById("Modal-Description").value;
                $Unit = document.getElementById("Modal-ConsUnit").value;
                $StockLocation = document.getElementById("Modal-StockLocation").value;
                $ConsUnit = document.getElementById("Modal-ConsUnit").value;
				$HsnCode = document.getElementById("Modal-HsnCode").value;
				$TaxPer = document.getElementById("Modal-TaxPer").value;
				
		
			
				
			
                  $.ajax({
               type :"POST",
               data : {MaterailType : $MaterailType,
                       PartName : $PartName,
                      PartNo: $PartNo,
                      PPCName : $PPCName,
                      Description : $Description,
                      Unit : $Unit,
                      StockLocation : $StockLocation,
                      ConsUnit : $ConsUnit,
					  HsnCode : $HsnCode,
					  TaxPer : $TaxPer},
               url  :"RawMaterialSave.php",
               dataType : "json",
               encode : true,
               success : function(){
                  
               }
            });
                
            }
