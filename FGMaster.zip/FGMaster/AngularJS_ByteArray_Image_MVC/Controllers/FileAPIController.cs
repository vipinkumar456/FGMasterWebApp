﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.IO;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace AngularJS_ByteArray_Image_MVC.Controllers
{
    public class FileAPIController : ApiController
    {
        [Route("api/FileAPI/UploadFiles")]
        [HttpPost]
        public HttpResponseMessage UploadFiles()
        {
            //Read the File from Request.Files collection.
            HttpPostedFile postedFile = HttpContext.Current.Request.Files[0];

            //Convert the File to Byte Array.
            BinaryReader br = new BinaryReader(postedFile.InputStream);
            byte[] bytes = br.ReadBytes(postedFile.ContentLength);


            //Send the Base64 string to the Client.
            return Request.CreateResponse(HttpStatusCode.OK, Convert.ToBase64String(bytes, 0, bytes.Length));
        }
    }
}
