<?php
        require("Db.php");
            $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
            $conn = sqlsrv_connect($serverName, $options);
            $RecID = $_POST['ModalRecID'];
			$PartNo = $_POST['PartNo'];
			$PPCName = $_POST['PPCName'];
			$Description = $_POST['Description'];
			
            $str=" dbo.[EmsNet_Proc_FinishedGoodMasterV1_Form_BeforeSave]
			     @RecID ='".$RecID."',
				 @PartNo	='".$PartNo."',
				 @PPCName	='".$PPCName."',
				  @Description	='".$Description."'";	
            $query = sqlsrv_query($conn,$str);
            $row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
                if($row)
                        {
                            echo json_encode($row); 
                        }    
?>