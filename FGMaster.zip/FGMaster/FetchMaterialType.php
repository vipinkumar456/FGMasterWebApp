<?php
require("Db.php");
$connectionInfo = array( "Database"=>$Database, "UID"=>$username, "PWD"=>$PWD,"CharacterSet" => "UTF-8");
$server = sqlsrv_connect ($serverName,$connectionInfo);
$query = sqlsrv_query($server,"dbo.CRM_Proc_Rating_Analysis");// where id='$cid'");
$datapoints=array();
$RecIDArray=array();
$data=array();
while( $row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC) ) {
	$data[]=$row;
}
echo json_encode($data, JSON_NUMERIC_CHECK);
?>