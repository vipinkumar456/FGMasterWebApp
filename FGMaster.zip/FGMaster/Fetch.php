<?php
        require("Db.php");
            $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
            $conn = sqlsrv_connect($serverName, $options);
            $recids = $_POST['RecID'];
            $str=" dbo.[EmsNet_Proc_FinishedGoodMasterV1Web_FetchDetails]
			     @RecID ='".$recids. 
                 "'" ;	
            $query = sqlsrv_query($conn,$str);
        do{
        if( $query === false) {
            print "Error";
            die( print_r( sqlsrv_errors(), true) );
        }
        $row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
        if(is_array($row) && array_key_exists('FGPhoto', $row))
        $cid = $row['FGPhoto'];
        $next_result = sqlsrv_next_result($query);
        if( $next_result){
        }
        else
            break;
    
       }
        while(1);
	echo json_encode($row, JSON_NUMERIC_CHECK);
?>