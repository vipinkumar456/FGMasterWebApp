<?php
        require("Db.php");
            $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
            $conn = sqlsrv_connect($serverName, $options);
            $NetWt = $_POST['NetWt'];
			$GrossWt = $_POST['GrossWt'];
			$ScrapWt = $_POST['ScrapWt'];
            $str=" dbo.[EmsNet_Proc_FinishedGoodMasterV1_NetWeight_Validation]
			     @NetWeight ='".$NetWt."',
				 @GrossWeight	='".$GrossWt."',
				 @ScrapWeight	='".$ScrapWt."'" ;	
            $query = sqlsrv_query($conn,$str);
            $row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
                if($row)
                        {
                            echo json_encode($row); 
                        }    
?>