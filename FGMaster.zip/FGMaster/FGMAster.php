

<?php
    
    require("Db.php");
        $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database,"CharacterSet" => "UTF-8" );
        $conn = sqlsrv_connect($serverName, $options);
?>
<!DOCTYPE html>
    <html lang="en" >
        <head>
					<title>Finished Good MasterV1</title>
					<meta charset="utf-8">
					<meta name="viewport" content="width=device-width, initial-scale=1">
					<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
					<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
					   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
					<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
					<link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" /> 
					<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
					<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
					 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.min.css">

 

					<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
					    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
					<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.9.1/underscore-min.js"></script> 	
					<script src= "https://code.jquery.com/jquery-3.5.1.js"> </script> 
					<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
					<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
					<script type="text/javascript" src="js/jquery.min.js"></script>
					<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
					<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>  
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
					<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>					
					 <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.jquery.min.js"></script>
					 
					
					
					
					
					<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
					<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
					<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
					



  
		
	


<style>
.chosen-container-single .chosen-single
{
	height:30px;
}


<!--   GradeTable Fix -->
.tableFix { /* Scrollable parent element */
  position: relative;
  overflow: auto;
  height: 100px;
}



.tableFix table{
  width: 100%;
  border-collapse: collapse;
}

.tableFix th,
.tableFix td{

  text-align: left;
}

.tableFix thead th {
  position: sticky;  /* Edge, Chrome, FF */
  top: -20px;
  background: #fff;  /* Some background is needed */
}

<!-- Grade Modal Header Fix ----->
#grademodal {
    overflow: hidden;
}
#grademodal .modal-body {
    height: 500px;
    overflow: auto;
}






.SectionTableFix { /* Scrollable parent element */
  position: relative;
  overflow: auto;
  height: 100px;
}

.SectionTableFix table{
  width: 100%;
  border-collapse: collapse;
}

.SectionTableFix th,
.SectionTableFix td{

  text-align: left;
}

.SectionTableFix thead th {
  position: sticky;  /* Edge, Chrome, FF */
  top: -20px;
  background: #fff;  /* Some background is needed */
}



#SectionModal {
    overflow: hidden;
}
#SectionModal .modal-body {
    height: 500px;
    overflow: auto;
}


.HsnTableFix { /* Scrollable parent element */
  position: relative;
  overflow: auto;
  height: 100px;
}

.HsnTableFix table{
  width: 100%;
  border-collapse: collapse;
}

.HsnTableFix th,
.HsnTableFix td{

  text-align: left;
}

.HsnTableFix thead th {
  position: sticky;  /* Edge, Chrome, FF */
  top: -20px;
  background: #fff;  /* Some background is needed */
}

#hsnmodal {
    overflow: hidden;
}
#hsnmodal .modal-body {
    height: 500px;
    overflow: auto;
}



.scrollit {
    overflow:scroll;

}
#AddButton
{

border:2px solid white;

}
body {
	   background:#ECEFF1;
   font-family: 'Roboto';font-size: 14px;font-weight:normal;
}
</style>
        </head>
		<body>
		
		
 <?php                                                                                                             
    $str = "select * from EmsNet_View_RawMaterialWeb_AdvancedFetch"; 
    $query = sqlsrv_query($conn,$str);
	$row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
		if($row)
          {
			

	
	$table  = array();
      do        {

		

       
      
            
			array_push($table,$row);
			foreach(array_keys($row) as $key)
                    {
                        $val=$row[$key];
						
							
										
																	
                    }
            echo "</tr>";
                }
            while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
			
			$RawMaterialTable  = json_encode($table,true);
			
			echo '<form> <input type="hidden" id ="RawMaterialTable" value=\''.$RawMaterialTable.'\' ></form>';
			
           }
                else
                {
                    echo '<td>No Records</td>';
                }   
				

?> 




<?php      
																					
        $str = "select Max(RecID) from Emsnet_Dbase_RawMaterialWeb"; 
        $query = sqlsrv_query($conn,$str);
        $row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
			if($row)
                {
			         echo "<tr  style='height:45px;border-radius:13px' >";
			             foreach(array_keys($row) as $key)
                            {
								
    			             echo '<th style="padding:4px;text-align:center;Min-width:130px;vertical-align:middle;background: #6c7ae0
                                    ;color:white;font-weight: normal;" >'.$key.'</th>';  
							
					        }
				      echo"</tr>";

    do              
                    {
					
					
                        echo '<tr >';
		                  foreach(array_keys($row) as $key)
                                {
                                    $MaxRecID=$row[$key];
									
					             
                                     '<td style="padding:2px;text-align:center;vertical-align:middle;Min-width:130px;height:50px;width:1130px;">'.$MaxRecID.'</td>';		
                                }
                      echo "</tr>";
                    }
                        while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
                }
            else
                {
                    '<td>No Records</td>';
                }        
?>    

   <?php                                                                                                             
    $str = "select RecID From EmsNet_Dbase_RawMaterialWeb order by RecID Desc"; 
    $query = sqlsrv_query($conn,$str);

	$row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
		if($row)
          {
			

	
	$table  = array();
      do        {

		

       
      
            
			array_push($table,$row);
			foreach(array_keys($row) as $key)
                    {
                        $val=$row[$key];
						
							
										
																	
                    }
            echo "</tr>";
                }
            while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
			
			$TableRecID  = json_encode($table,true);
			// echo $tablejson;
			echo '<form> <input type="hidden" id ="TableRecID" value=\''.$TableRecID.'\' ></form>';
			
           }
                else
                {
                    echo '<td>No Records</td>';
                }   
				

?>  




   <?php                                                                                                             
    $str = "EmsNet_Proc_RawMaterialMasterV1_MaterialType_GetValue"; 
    $query = sqlsrv_query($conn,$str);

	$row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
		if($row)
          {
			

	
	$table  = array();
      do        {

		

       
      
            
			array_push($table,$row);
			foreach(array_keys($row) as $key)
                    {
                        $val=$row[$key];
						
							
										
																	
                    }
            echo "</tr>";
                }
            while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
			
			$MaterialType  = json_encode($table,true);
			// echo $tablejson;
			echo '<form> <input type="hidden" id ="partbnametable" value=\''.$MaterialType.'\' ></form>';
			
           }
                else
                {
                    echo '<td>No Records</td>';
                }   
				

?>  

<!-- PartName Get Value -->

<!------------           Tolerance Get Value Start       -------------------------------------------->

	   <?php                                                                                                             
    $str = "EmsNet_Proc_RawMaterialMasterV1_TolerenceType_GetValue"; 
    $query = sqlsrv_query($conn,$str);

	$row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
		if($row)
          {
			

	
	$table  = array();
      do        {

		

       
      
           
			array_push($table,$row);
			foreach(array_keys($row) as $key)
                    {
                        $val=$row[$key];
						
							
										
																	
                    }
            echo "</tr>";
                }
            while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
			
			$ToleranceTable  = json_encode($table,true);
		
			echo '<form> <input type="hidden" id ="ToleranceTable" value=\''.$ToleranceTable.'\' ></form>';
			
           }
                else
                {
                    echo '<td>No Records</td>';
                }   
				

?>  





<!------------          Tolerance Get Value Close       --------------------------------------------- >

<!-- HSN Code Get Value  --->

				  
 <?php                                                                                                             
    $str = "EmsNet_Proc_RawMaterialMasterV1_HSNCode_GetValue"; 
    $query = sqlsrv_query($conn,$str);
	$row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
		if($row)
          {
			

	
	$table  = array();
      do        {

		

       
      
            
			array_push($table,$row);
			foreach(array_keys($row) as $key)
                    {
                        $val=$row[$key];
						
							
										
																	
                    }
            echo "</tr>";
                }
            while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
			
			$hsncode  = json_encode($table,true);
			
			echo '<form> <input type="hidden" id ="hsntable" value=\''.$hsncode.'\' ></form>';
			
           }
                else
                {
                    echo '<td>No Records</td>';
                }   
				

?>  
<!--Hsn Code Get Value Close -->




<!-- Section Get Value Start-->
<?php
    require("Db.php");
        $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
        $conn = sqlsrv_connect($serverName, $options);
?>	
   <?php 
$pageno='Bar';
    $str = "EmsNet_Proc_RawMaterialMasterV1_Section_GetValue @MaterialType ='".$pageno."',@Shape ='".$pageno."'"; 

    $query = sqlsrv_query($conn,$str);
	
	$row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
		if($row)
          {
			

	
	$table  = array();
      do        {

		

       
      
            
			array_push($table,$row);
			foreach(array_keys($row) as $key)
                    {
                        $val=$row[$key];
						
							
										
																	
                    }
            echo "</tr>";
                }
            while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
			
			$section  = json_encode($table,true);
			
			echo '<form> <input type="hidden" id ="partnametable" value=\''.$section.'\' ></form>';
			
           }
                else
                {
                    echo '<td>No Records</td>';
                }   
				

?>  

<!-- Unit Get Value Close-->

<?php
    require("Db.php");
        $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
        $conn = sqlsrv_connect($serverName, $options);
?>	
   <?php 
$pageno='Bar';
    $str = "EmsNet_Proc_FinishedGoodMasterV1_Unit_GetValue"; 

    $query = sqlsrv_query($conn,$str);
	
	$row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
		if($row)
          {
			

	
	$table  = array();
      do        {

		

       
      
            
			array_push($table,$row);
			foreach(array_keys($row) as $key)
                    {
                        $val=$row[$key];
						
							
										
																	
                    }
            echo "</tr>";
                }
            while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
			
			$unit  = json_encode($table,true);
			
			echo '<form> <input type="hidden" id ="UnitTable" value=\''.$unit.'\' ></form>';
			
           }
                else
                {
                    echo '<td>No Records</td>';
                }   
				

?>  


<!-----                          Product Type Get Value ---------------------------->
<?php
    require("Db.php");
        $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
        $conn = sqlsrv_connect($serverName, $options);
?>	
   <?php 
$pageno='Bar';
    $str = "EmsNet_Proc_FinishedGoodMasterV1_ProductType_GetValue"; 

    $query = sqlsrv_query($conn,$str);
	
	$row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
		if($row)
          {
			

	
	$table  = array();
      do        {

		

       
      
            
			array_push($table,$row);
			foreach(array_keys($row) as $key)
                    {
                        $val=$row[$key];
						
							
										
																	
                    }
            echo "</tr>";
                }
            while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
			
			$ProductType  = json_encode($table,true);
			
			echo '<form> <input type="hidden" id ="ProductType" value=\''.$ProductType.'\' ></form>';
			
           }
                else
                {
                    echo '<td>No Records</td>';
                }   
				

?>  

<!---------------------                                        --------------------------->



<!-------------------------  ParameterAdvanceSearchStart                     ---------------------------------------->

   <?php 
$Parameter='PartName';
    $str = "EmsNet_Proc_RawMaterialWeb_AdvancedSearch @Parameter ='".$Parameter."'"; 

    $query = sqlsrv_query($conn,$str);
	
	$row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
		if($row)
          {
			

	
	$table  = array();
      do        {

		

       
      
            
			array_push($table,$row);
			foreach(array_keys($row) as $key)
                    {
                        $val=$row[$key];
						
							
										
																	
                    }
            echo "</tr>";
                }
            while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
			
			$ParameterAdvancedSearchTable  = json_encode($table,true);
			
			echo '<form> <input type="hidden" id ="ParameterAdvancedSearchTable" value=\''.$ParameterAdvancedSearchTable.'\' ></form>';
			
           }
                else
                {
                    echo '<td>No Records</td>';
                }   
				

?>  

<!-------------------------  ParameterAdvanceSearchClose                     ---------------------------------------->
					
		
			<div class="container" >

				<div class="row" style="margin-top:10px;margin-bottom:10px" >	
					<div class="col-sm-1" style="background-color:">
				
					</div>
					<div class="col-sm-10" style="box-shadow: 0px 1px 2px 1px grey;border-radius:10px;background-color:#fafafa;">
										  <div class="row">
										  <div class="col-sm-3">
												<div class="row"  style="margin-top:55px;margin-left:10px">
													
													<img id="blah" src="#" alt="your image" />
													<img src="Nahata.png" id="ImageOnLoad" style="width:200px;height:240px">
													<input style="margin-top:10px" id="FileImage" type='file' onchange="readURL(this);" />
												</div>
												
												<div class="row" style="margin-top:30px">
														  <div class="form-group">
																<label for="Username" class="col-sm-5 control-label">HSN Code: </label>
																  <div class="col-sm-7">
																	<input type="textbox" id="Modal-HsnCode" name="HsnCode" onclick="HsnOpen()" class="form-control">
																	
																  </div>
																  
														  </div>
												</div>
												<div class="row" style="margin-top:30px">
														  <div class="form-group">
																<label for="Username" class="col-sm-5 control-label">Tax %: </label>
																  <div class="col-sm-7">
																	<input type="textbox" id="Modal-TaxPer" name="TaxPer"  class="form-control">
																	
																  </div>
																  
														  </div>
												</div>
										  </div>
												<div class="col-sm-9">
												  <div class="register form-horizontal">
												  <div class="row">
												  <center><p style="font-weight:normal">
																									<span id="CountChange"><?php echo $MaxRecID ?></span>/
																									<span id="followup">
																								<?php echo $MaxRecID ?>
																									</span>
																								</p></center>
												  </div>
													
														  <div class="form-group" style="margin-top:20px">
															
															 <input type="hidden" class="form-control" id="Modal-CustomerID" name="CustomerID">
																<input type="hidden" class="form-control" id="Modal-RecID" name="RecID">
																<input type="hidden" class="form-control" id="Modal-StartRecID"  value="<?php echo $MaxRecID ?>" name="RecID">
																<input type="hidden" class="form-control" id="CountMaxRecID"  value="<?php echo $MaxRecID ?>" name="RecID">
																  <input type="hidden" class="form-control" id="Modal-Mode" name="RecID" Value="Add">
															  
																
																
														  </div>

														  <div class="form-group">
															<label for="Matric_no" class="col-sm-2 control-label">Part Name: </label>
															  <div class="col-sm-10">
																	<input name="PartName" id="Modal-PartName"  class="form-control" >

																	</select>
															  </div>
														  </div>


														  <div class="form-group">
															<label for="Email" class="col-sm-2 control-label">Part No: </label>
															  <div class="col-sm-8">
																<input name="PartNo" id="Modal-PartNo"  class="form-control" disabled>

																
															
															  </div>
																
														  </div>

														  <div class="form-group">
															<label for="Username" class="col-sm-2 control-label">PPC Name: </label>
															  <div class="col-sm-7">
																<input name="PPCName"  id="Modal-PPCName" class="form-control" disabled>
															  </div>
															   <label for="Username" class="col-sm-1 control-label">Unit: </label>
															  <div class="col-sm-2" >
																<select name="Unit" id="Modal-Unit"	 class="form-control livesearch" style="height:34px"  >
																
																	
																	 <?php  
																											 $json =$unit;
																											echo $json;
																												 $koyim = json_decode($json, true);
																												// echo $koyim['0'];
																												foreach($koyim as $value)
																												{
																													$Unit = $value['Unit'];
																													
																												   echo'<pre>';
																												   print_r( "<option value=\"$Unit\">$Unit</option>");

																													 echo'</pre>';
																												}
																											 
																												?>
																</select>
															  </div>
															
														  </div>
														  
														  <div class="form-group">
															<label for="Username" class="col-sm-2 control-label">Description: </label>
															  <div class="col-sm-7">
																<input name="Description" id="Modal-Description" class="form-control" disabled>
															  </div>
															 
														  </div>

														 <div class="form-group">
														 <label for="Username" class="col-sm-2 control-label">Product Type</label>
															  <div class="col-sm-4">
															   <select id="Modal-ProductType" name="ProductType"  class="form-control livesearch" style="height:"   > 
																<option value=""></option>
																	 <?php  
																											 $json =$ProductType;
																											echo $json;
																												 $koyim = json_decode($json, true);
																												// echo $koyim['0'];
																												foreach($koyim as $value)
																												{
																													$ProductType = $value['ProductType'];
																													
																												   echo'<pre>';
																												   print_r( "<option value=\"$ProductType\">$ProductType</option>");

																													 echo'</pre>';
																												}
																											 
																												?>
																</select>
															  </div>
														 
															<label for="Username" class="col-sm-2 control-label">Stock Location: </label>
															  <div class="col-sm-4">
																<input name="StockLocation" id="Modal-StockLocation" class="form-control" disabled>
															  </div>
															  
														  </div>
														  
														
														  
														   <div class="form-group">
															<label for="Username" class="col-sm-2 control-label">Net Wt.</label>
															  <div class="col-sm-2">
																<input name="NetWt" id="Modal-NetWt" class="form-control" disabled>
															  </div>
															  <div class="col-sm-2">
																<input name="NetWtUnit" type="textbox" id="Modal-NetWtUnit" onblur="NetWtValidation()"  class="form-control" disabled>
															  </div>
															  <div class="col-sm-2">
															  </div>
														 
															<label for="Username" class="col-sm-2 control-label">Min. Stock Level </label>
															  <div class="col-sm-2">
																<input name="StockLocation" id="Modal-MinStockLevel" class="form-control" disabled>
															  </div>
															  
														  </div>
														  
														   <div class="form-group">
															<label for="Username" class="col-sm-2 control-label">Gross Wt.</label>
															  <div class="col-sm-2">
																<input name="Gwt" id="Modal-Gwt" class="form-control" disabled>
															  </div>
															  <div class="col-sm-2">
																<input name="GwtUnit" type="textbox" id="Modal-GwtUnit" class="form-control" disabled>
															  </div>
															  <div class="col-sm-2">
															  </div>
														 
															<label for="Username" class="col-sm-2 control-label">Max. Stock Level </label>
															  <div class="col-sm-2">
																<input name="MaxStockLevel" id="Modal-MaxStockLevel" class="form-control" disabled>
															  </div>
															  
														  </div>
														  
														  <div class="form-group">
															<label for="Username" class="col-sm-2 control-label">Scrap Wt.</label>
															  <div class="col-sm-2">
																<input name="ScrapWt" id="Modal-ScrapWt" class="form-control" disabled>
															  </div>
															  <div class="col-sm-2">
																<input name="ScrapWtUnit" type="textbox" id="Modal-ScrapWtUnit" class="form-control" disabled>
															  </div>
															  <div class="col-sm-1">
															  </div>
														 
															<label for="Username" class="col-sm-3 control-label">Reorder Stock Level </label>
															  <div class="col-sm-2">
																<input name="ReorderStockLevel" id="Modal-ReorderStockLevel" class="form-control" disabled>
															  </div>
															  
														  </div>
														
												 </div>
											</div>
										 </div>

													   <div class="row" style=>
																	<div class="col-lg-2 col-sm-4 col-xs-4">
																	<input type="Submit" class="btn btn-primary" style="width:100px;margin-bottom:10px" id="AddStartButton" value="Add" onclick="Enable()"></input>
																	</div>
																	<div class="col-lg-2 col-sm-4 col-xs-4">
																	<input type="Submit" class="btn btn-primary" id="EditButton" onclick="fetchResult()" value="Edit" style="width:100px;margin-bottom:10px"></input>
																	</div>
																	<div class="col-lg-2 col-sm-4 col-xs-4">
																	<input type="Submit" class="btn btn-primary" value="Save" id="SaveButton" style="width:100px;margin-bottom:10px" onclick="UpdateAgentDetails()">
																	</div>
																	<div class="col-lg-2 col-sm-4 col-xs-4">
																	<button type="button" class="btn btn-primary"  style="width:100px;margin-bottom:10px" id="FindButton" onclick="FindFunction()">FIND</button>
																	</div>
																	<div class="col-lg-2 col-sm-4 col-xs-4">
																	<button type="button" class="btn btn-primary" onclick="DeleteFunction()" id="DeleteButton" style="width:100px;margin-bottom:10px">Delete</button>
																	</div>
																	<div class="col-lg-2 col-sm-4 col-xs-4">
																	<button type="button" class="btn btn-primary" style="width:100px;margin-bottom:10px">EXIT</button>
																	</div>
																	
																	
															 </div>
														<div class="row" style="margin-bottom:10px">
														  <div class="col-sm-6">	
															 <button type="button"  style="float:left;width:100px" onclick="PreviousFunction()" class="btn btn-success">Previous</button>
														  </div>
														   <div class="col-sm-6">	
															 <button type="button" style="float:right;width:100px" onclick="NextFunction()" class="btn btn-success">Next</button>
														  </div>		
														</div>
					</div>
					<div class="col-sm-1" style="background-color:	">
					</div>
				</div>
														
				
				
<!----                               	 open                                                                 		
				<div class="modal fade" id="Modaltoggle" style="" role="dialog" data-backdrop="static" data-keyboard="false">
                                            <div class="modal-dialog" style="">
                                                <div class="modal-content">
                                                        <div class="modal-header" style="background-color:#919aa2">
                                                            <button type="button" class="close" data-dismiss="modal" style="font-size:34px"  >&times;</button>
                                                         
																			<p style="font-weight:normal">
									
												
                                                        </div>
                                                        <div class="modal-body" style="margin-bottom:20px">
															<div class="row">
															
																 <div class="form-group">
																	  <label for="Username" class="col-sm-2 control-label">Grade</label>
																	  <div class="col-sm-10">
																	
																		<input name="StockLocation" autocomplete="off" id="Modaltoggle-Grade" class="form-control" onclick="GradeOpen()" >
																		<input name="StockLocation" type="hidden" autocomplete="off" id="Modaltoggle-Material" class="form-control"  >
																	  </div>
																	
																 </div>	  
																
																 <div class="form-group"  >
																	<div id="ShapeHide">
																	<label for="Username" class="col-sm-2 control-label" id="Shape" style="margin-top:10px">Shape </label>
																	  <div class="col-sm-4" style="margin-top:10px">
																		<select id="Modaltoggle-Shape" name="Shape"   class="form-control" style="height:" > 
																				   <option value="-">Select</option>
																				  <option value="Round">Hexagonal</option> 
																				  <option value="Sheet">Rectangular</option>
																				  <option value="Strip">Round</option> 
																				  <option value="Sheet">Square</option>
																				 
																				 
																		</select>
																	  </div>
																	  </div>
																	 <div id="SectionHide">
																	  <label for="Username" class="col-sm-2 control-label" id="Section" style="margin-top:10px">Section</label>
																	  <div class="col-sm-4" style="margin-top:10px">
																		<input name="Section" autocomplete="off" id="Modaltoggle-Section" class="form-control" onclick="SectionOpen()" >
																		<!--<select id="Modaltoggle-Section" name="State"  class="form-control" style="height:" > 
																				   <option value="-"></option>
																				
																			  section;
																				echo $json;
																					 $koyim = json_decode($json, true);
																					// echo $koyim['0'];
																					foreach($koyim as $value) {
																						$Section = $value['Section'];
																						
																					   echo'<pre>';
																					   print_r( "<option value=\"$Section\">$Section</option>");

																						 echo'</pre>';
																					}
																				 
																				
																				 
																				 
																		</select>
																	
																	  </div>
																	</div>
																	  
																  </div>
																  
																  <div class="form-group" >
																	<label for="Username" class="col-sm-3 control-label" id="Thickness/Dia" style="margin-top:10px">Thickness/Dia</label>
																	  <div class="col-sm-3" style="margin-top:10px">
																		<input name="Thickness" id="Modaltoggle-Thickness" type="textbox" autocomplete="off" class="form-control">
																	  </div>
																	  <div id="WidthDiv">
																	  <label for="Username" class="col-sm-2 control-label" id="Width" style="margin-top:10px">Width</label>
																	  <div class="col-sm-4" style="margin-top:10px">
																		<input name="Width" id="Modaltoggle-Width" autocomplete="off"  class="form-control" >
																	  </div>
																	  </div>
																  </div>
																  
																   <div class="form-group" >
																	<div id="LengthDiv">
																		<div class="col-sm-3"  id="ModalToggleCheckBox"  style="margin-top:10px">
																		<input type="checkbox" id="Modaltoggle-VarLength" name="CheckBox" value="0" onclick="CheckBox()" autocomplete="off">
																		<label for="vehicle1">Length</label><br>
																		</div>
																	   <div class="col-sm-3" id="LengthHide" style="margin-top:10px">
																		<input name="Length" id="Modaltoggle-Length"  class="form-control"  autocomplete="off">
																	   </div>
																	   </div>
																	  <label for="Username" class="col-sm-2 control-label" style="margin-top:10px">Tolerance</label>
																	  <div class="col-sm-2" style="margin-top:10px">
																		  <select id="Modaltoggle-ToleranceType" name="Modaltoggle-ToleranceType"   class="form-control selectpicker" style="height:"  data-live-search="true"> 
																		
																			 // <?php  
																			     // $json =$ToleranceTable;
																				// echo $json;
																					 // $koyim = json_decode($json, true);
																					// echo $koyim['0'];
																					// foreach($koyim as $value)
																					// {
																						// $ToleranceTable = $value['TolerenceType'];
																						
																					   // echo'<pre>';
																					   // print_r( "<option value=\"$ToleranceTable\">$ToleranceTable</option>");

																						 // echo'</pre>';
																					// }
																				 
																					// ?>
																				</select>	
																	  </div>
																	  <div class="col-sm-2" style="margin-top:10px">
																		<input name="Tolerance" id="Modaltoggle-Tolerance"  class="form-control" autocomplete="off" >
																	  </div>
																  </div>
																		<input name="GradeID" id="Modaltoggle-GradeID" type="hidden" class="form-control" autocomplete="off" >

															</div>
															
															<center><input type="Submit" class="btn btn-primary" value="Submit" onclick="ModaltoggleSubmit()" style="width:120px;margin-top:20px"></center>
														</div>
                                                      <!--  <div class="modal-footer" style="background-color:">
                                                                <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload();">Close</button>
                                                        </div> 
                                                </div>
                                            </div>
                                    </div> 
					<!----------------------------                         Modal Open Close                            ----->
					
					
							<!-------------------------   Close Enquiry Modal Open    ---------------------------------------------	
					
					  <div class="modal fade" id="grademodal" style="margin-top:0px;max-height: 88%;" role="dialog" data-backdrop="static" data-keyboard="false">
                                            <div class="modal-dialog" style=" 
  ">
                                                <div class="modal-content">
                                                        <div class="modal-header" style="background-color:aliceblue;">
                                                            <button type="button" class="close" data-dismiss="modal" style="font-size:34px"  >&times;</button>
															<div class="row" style="padding-left:10px;margin-left:10px;margin-right:10px;margin-top:10px"><center><h4 class="modal-title" style="position:fixed;">Select Grade</h4></div></center>
                                                        </div>
														<div class="row"><input id="GradeTableSearch" type="text" class="form-control" style="    max-width: 91%;
    margin-bottom: 10px;
    margin-left: 27px;" placeholder=""></div>
			                                    
                                                        <div class="modal-body tableFix" >
												            <table id="GradeTable" class="table table-hover" style="opacity: 1.3">
                                                                <div>
                                                                    <div>
                                                                        <thead style="box-shadow: 1px 1px 2px 1px lightgray;border-radius:13px;">
// <?php
    // require("Db.php");
        // $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
        // $conn = sqlsrv_connect($serverName, $options);
// ?>	
// <?php      
                                                                                
       // $str = "Select Material,Grade from EmsNet_MasterPool_MaterialGrade order by Grade"; 
        // $query = sqlsrv_query($conn,$str);
        // $row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
			// if($row)
                // {
			         // echo "<tr  style='height:45px;border-radius:13px' >";
			             // foreach(array_keys($row) as $key)
                            // {
								
    			             // echo '<th style="padding:4px;text-align:center;vertical-align:middle;background: #6c7ae0
                                    // ;color:white;font-weight: normal;width:20px;" >'.$key.'</th>';  
								
					        // }
				      // echo"</tr>";
// ?>
                                                                        </thead  >
						                                                <tbody  style="height:140px;box-shadow: 1px 1px 2px 1px lightgray;margin-top:10px">
// <?php
    // do              
                    // {
						// $Material=$row['Material'];
						// $Grade=$row['Grade'];
						
                        // echo "<tr highlighttr\" onclick=\"GradeTableDetails('$Material','$Grade')\">";
		                  // foreach(array_keys($row) as $key)
                                // {
                                    // $val=$row[$key];
					              
                                    // echo '<td style="padding:2px;text-align:center;vertical-align:middle;height:50px;width:20px">'.$val.'</td>';		
                                // }
                      // echo "</tr>";
                    // }
                        // while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
                // }
            // else
                // {
                    // echo '<td>No Records</td>';
                // }        
// ?>          
                                                                        </tbody>		
                                                                    </div>
                                                                </div>
                                                            </table>																  
		                                                          

                                                        </div>
                                                      <!--  <div class="modal-footer" style="background-color:">
                                                                <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload();">Close</button>
                                                        </div>
                                                </div>
                                            </div>
                                    </div>
									
									
									
		<!-------------------------   Close ENquiry Modal Close    ----------------------------------------------->		



<!---------------------------------   Section Modal Start-------------------------------------->
			
								
											<!--  <div class="modal fade" id="SectionModal" style="margin-top:" role="dialog" data-backdrop="static" tabindex="-1" data-keyboard="false" aria-hidden="true"> 
																	<div class="modal-dialog" style="max-height:70% ">
																		<div class="modal-content">
																				<div class="modal-header" style="background-color:aliceblue">
																					<button type="button" class="close" data-dismiss="modal" style="font-size:34px"  >&times;</button>
																					<div class="row" style="margin-left: 39%;"><h4 class="modal-title" style="position:fixed;">Select Section</h4></div>
																					<div class="row">
																						<div class="col-sm-10 col-xs-9">
																							<input id="SectionTableSearch" type="text" class="form-control" style="max-width:100%;margin-top:" placeholder="">
																						</div>
																						<div class="col-sm-2 col-xs-3">
																							<input type="button" style="" class="btn btn-primary" onclick="SectionInsertOpen()" Value="Insert">
																						</div>	
																						
																							
																					</div>
																				</div>
																				<div class="modal-body SectionTableFix">
																					<input type="hidden" class="form-control" id="leadinfoModal-RecID" name="RecID">
																				  <table id="leadDetailsinfo-table"  class="table ">
                                                                                    <div >
                                                                                        <thead id="LeadInfoHeaders" style="">
                                                                                            

                                                                                        </thead >
                                                                                        <tbody  style="">

                                                                                        </tbody>		
                                                                                        
                                                                                    </div>
                                                                                </table>
																					<table id="SectionTable" class="table table-hover" style="opacity: 1.3">
																						 <div>
																							 <div>
																									 <thead style="box-shadow: 1px 1px 2px 1px lightgray;border-radius:13px;">
							 // <?php
								 // require("Db.php");
									 // $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
									 // $conn = sqlsrv_connect($serverName, $options);
							 // ?>	
							// <?php      
										// $pageno='Bar';																	
								   // $str = "EmsNet_Proc_RawMaterialMasterV1_Section_GetValue @MaterialType ='".$pageno."',@Shape ='".$pageno."'"; 
									// $query = sqlsrv_query($conn,$str);
									// $row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
										// if($row)
											// {
												 // echo "<tr  style='height:45px;border-radius:13px' >";
													 // foreach(array_keys($row) as $key)
														// {
															
														 // echo '<th style="padding:4px;text-align:center;vertical-align:middle;background: #6c7ae0
																// ;color:white;font-weight: normal;width:20px" >'.$key.'</th>';  
															
														// }
												  // echo"</tr>";
							// ?>
																									 </thead  >
																									<tbody  style="height:140px;box-shadow: 1px 1px 2px 1px lightgray">
							 // <?php
								// do              
												// {
													// $ParmValue=$row['Section'];
						
													
													// echo "<tr highlighttr\" onclick=\"ModaltoggleSection('$ParmValue')\">";
													  // foreach(array_keys($row) as $key)
															// {
																// $val=$row[$key];
															  
																// echo '<td style="padding:2px;text-align:center;vertical-align:middle;height:50px;width:20px">'.$val.'</td>';		
															// }
												  // echo "</tr>";
												// }
													// while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
											// }
										// else
											// {
												// echo '<td>No Records</td>';
											// }        
							// ?>          
																									 // </tbody>		
																								 </div>
																							 </div>
																					 </table>																  
																						  

																				</div>
																				 
																		</div>
																	</div>
															</div>
									
		

<!---------------------------------   Section Modal Close ----------------------------------


		<div class="modal fade" id="SectionInsertModal" style="" tabindex="-1" role="dialog" aria-labelledby="SectionInsertModal" aria-hidden="true">
							<div class="modal-dialog modal-dialog-scrollable" style="" role="document">
							  <div class="modal-content">
								<div class="modal-header" style="background-color:aliceblue">
                                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								  </button>
								  <h5 class="modal-title" ></h5>
								 
								</div>
								<div class="modal-body">
								  
																								
												<input type="textbox" id="SectionModal-Section" class="form-control">
												
												<center><input type="submit" style="margin-top:10px" class="btn btn-secondary" value="Update" onclick="SectionUpdate()"></center>	
																								
																						 
																							
								
								</div>
								
							  </div>
							</div>
		</div>

<!---------------------------                       Section Insert
		<!---------------------------------      HSNCOde And TAXper Start                         ----------------------------------------->
			<div class="modal fade" id="hsnmodal" style="margin-top:79px" role="dialog" data-backdrop="static" data-keyboard="false">
                                            <div class="modal-dialog" style=" max-height:80%; ">
                                                <div class="modal-content">
                                                        <div class="modal-header" style="background-color:aliceblue">
                                                            <button type="button" class="close" data-dismiss="modal" style="font-size:34px" >&times;</button>
															<div class="row"><h4 class="modal-title" style="position:fixed;">Select HsnCode</h4></div>
															<input id="HsnTableSearch" type="text" autocomplete="off" class="form-control" style="max-width:100%;margin-bottom:10px" placeholder="">
                                                        </div>
                                                        <div class="modal-body HsnTableFix">
												
			                                                <table id="HsnTable" class="table table-hover" style="opacity: 1.3">
                                                                <div>
                                                                    <div>
                                                                        <thead style="box-shadow: 1px 1px 2px 1px lightgray;border-radius:13px;">
<?php
    require("Db.php");
        $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
        $conn = sqlsrv_connect($serverName, $options);
?>	
<?php      
                                                                                
       $str = "EmsNet_Proc_RawMaterialMasterV1_HSNCode_GetValue"; 
        $query = sqlsrv_query($conn,$str);
        $row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
			if($row)
                {
			         echo "<tr  style='height:45px;border-radius:13px' >";
			             foreach(array_keys($row) as $key)
                            {
								
    			             echo '<th style="padding:2px;text-align:center;vertical-align:middle;background: #6c7ae0
                                    ;color:white;font-weight: normal;" >'.$key.'</th>';  
								
					        }
				      echo"</tr>";
?>
                                                                        </thead  >
						                                                <tbody  style="height:140px;box-shadow: 1px 1px 2px 1px lightgray">
<?php
    do              
                    {
						$HsnCode=$row['HSNCode'];
						$TaxPer=$row['TaxPer'];
						
                        echo "<tr highlighttr\" onclick=\"HsnTableDetails('$HsnCode','$TaxPer')\">";
		                  foreach(array_keys($row) as $key)
                                {
                                    $val=$row[$key];
					              
                                    echo '<td style="padding:2px;text-align:center;vertical-align:middle;height:50px;">'.$val.'</td>';		
                                }
                      echo "</tr>";
                    }
                        while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
                }
            else
                {
                    echo '<td>No Records</td>';
                }        
?>          
                                                                        </tbody>		
                                                                    </div>
                                                                </div>
                                                            </table>																  
		                                                          

                                                        </div>
                                                      <!--  <div class="modal-footer" style="background-color:">
                                                                <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload();">Close</button>
                                                        </div> -->
                                                </div>
                                            </div>
                                    </div>
									
									
		<!------------------------------------ HSNCODE ANd TaxPer Close         ------------------------------>		


	<!----------------------------------------------------  Section Insert Modal Start-------------------------------------------------------	
	
	<div class="modal fade" id="SectionModal" style="margin-top:79px" role="dialog" data-backdrop="static" data-keyboard="false">
                                            <div class="modal-dialog" style="overflow-y: scroll; max-height:80%; ">
                                                <div class="modal-content" style="    width: 44%;
    float: right;">
                                                        <div class="modal-header" style="background-color:">
                                                            <button type="button" class="close" data-dismiss="modal" style="font-size:34px" >&times;</button>
															<h4 class="modal-title" style="position:fixed;">Insert Section</h4>
                                                        </div>
                                                        <div class="modal-body">
															
															<input type="textbox" id="SectionModal-Section" class="form-control">
															<center><input type="submit" style="margin-top:10px" onclick="SectionUpdate()"></center>
					
                                                        
                                                      <!--  <div class="modal-footer" style="background-color:">
                                                                <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload();">Close</button>
                                                        </div> 
														</div>
                                            </div>
                                    </div>
									
							</div>		
	
	
	<!---------------------------------------------------- Section Insert Modal Close ------------------------------------------------------->

					
					<!-------------------------  Find Modal Start                 --------------------------------------------->
					<div class="modal fade" id="findmodal" style="margin-top:79px;" role="dialog" data-backdrop="static" data-keyboard="false">
                                            <div class="modal-dialog" style="">
                                                <div class="modal-content" style="width:%">
                                                       <div class="modal-header" style="background-color:aliceblue;">
                                                            <button type="button" class="close" data-dismiss="modal" style="font-size:34px;margin-top:-14px" onclick="window.location.reload();">&times;</button>
															
                                                       </div>
                                                        <div class="modal-body" >
															<div class="row">
																	<div class="col-sm-12" style="overflow-y:scroll;max-height:230px;width:95%;margin-left:10px">
																		<table id="FindTable" class="table table-hover" style="opacity: 1.3;height:200px;overflow-y:scroll;">
																	
																		<div >
																			<thead style="box-shadow: 1px 1px 2px 1px lightgray;border-radius:13px;">
																			<?php
																				require("Db.php");
																					$options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
																					$conn = sqlsrv_connect($serverName, $options);
																				
																				  
																																							
																				   $str = "select  PartName,PartNo,Description,PPCName,RecID from EmsNet_Dbase_RawMaterialWeb"; 
																					$query = sqlsrv_query($conn,$str);
																					$row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC);
																						if($row)
																							{
																								 echo "<tr >";
																									 foreach(array_keys($row) as $key)
																										{
																											
																										 echo '<th style="padding:4px;text-align:center;vertical-align:middle;background: #6c7ae0;color:white;position;font-weight: normal;min-width:200px;" >'.$key.'</th>';  
																											
																										}
																								  echo"</tr>";
																			?>
																			</thead  >
																		<tbody   style="height:140px;box-shadow: 1px 1px 2px 1px lightgray;">
																			<?php
																				do              
																								{
																									
																							$FindRecID = $row['RecID'];		
																								
																									echo "<tr highlighttr\" onclick=\"FindDetails('$FindRecID')\">";
																									  foreach(array_keys($row) as $key)
																											{
																												$val=$row[$key];
																											  
																												echo '<td style="padding:2px;min-width:200px;text-align:center;height:1px;vertical-align:middle;">'.$val.'</td>';		
																											}
																								  echo "</tr>";
																								}
																									while ($row = sqlsrv_fetch_array( $query, SQLSRV_FETCH_ASSOC));
																							}
																						else
																							{
																								echo '<td>No Records</td>';
																							}        
																			?>				
			
																				</tbody>		
																			</div>
																			
																		</table>
																																			
																	</div>
																	
															
															</div>
												
			                                      					<hr style="height:1px;border-width:0;color:gray;background-color:#846363;margin-top:9px">									  
															<div class="row" style="margin-top:20px" >
																	
																	<div class="col-sm-3" style="margin-top:10px">
																		<select id="PartyAdvancedSearch" name=""     class="state form-control" style="height:" > 
																					 <option value="" id="HideOnChange"> </option> 
																					  <option value="">RecID</option> 
																					  <option value="">MaterialType</option>
																					  <option value="">PartName</option> 
																					  <option value="">PartNo</option>
																					  <option value="">PPCName</option> 
																					  <option value="">Description</option>
																					  <option value="">Unit</option> 
																					  <option value="">StockLocation</option>
																					  <option value="">ConsUnit</option> 
																					  <option value="">HsnCode</option>
																					  <option value="">TaxPer</option> 
																					  <option value="">TD</option>
																					  <option value="">Grade</option> 
																					  <option value="">Shape</option>
																					  <option value="">Section</option>
																					   <option value="">Thickness</option> 
																					  <option value="">Width</option>
																					  <option value="">Length</option> 
																					  <option value="">Tolerance</option>
																					  <option value="">ToleranceType</option> 
																					  <option value="">VarLength</option>
																					
																		<script type="text/javascript">
																							 $('#PartyAdvancedSearch').on('change', function() {
																												
																									document.getElementById("HideOnChange").style.display="none";			
																												$PartyAdvancedSearch = document.getElementById('PartyAdvancedSearch');	
																												$SelectedFilter=$PartyAdvancedSearch.options[$PartyAdvancedSearch.selectedIndex].text
																												// alert($SelectedFilter);
																												$RMJson=document.getElementById('RawMaterialTable').value;
																												var arr = JSON.parse($RMJson);
																												document.getElementById("ParameterAdvancedSearch")
                                                                                                                  .innerHTML="";
																												  
																												 
																												var valuearr = [];
																												var p=0;  
																												for (var i = 0; i < arr.length; i++){
																												  // document.write("<br><br>array index: " + i);
																												  var obj = arr[i];
																												  
																												  for (var key in obj){
																													  if(key==$SelectedFilter)
																													  {
																														// console.log(obj[key]);
																														$selectedvalue = String(obj[key]).trim();
																														ParameterAdvancedSearchCombo = document.getElementById("ParameterAdvancedSearch");
																														var exists = false;
																														
																														for (q = 0; q < valuearr.length; q++) {
																															if(valuearr[q] == $selectedvalue) {
																																exists = true;
																															}
																														}
																														
																														if(!exists && $selectedvalue.length>0)
																														{
																															valuearr[p++] = $selectedvalue;
																														}
                                                                                                                    	// $('#ParameterAdvancedSearch').each(function(){
																															// if (this.value == $selectedvalue) {
																																// exists = true;
																															// }
																														// });
																														
																													  }
																												  }
																												  
																												}
																												valuearr.sort();
																												for(var r=0;r<valuearr.length;r++)
																													{
																														var opt = document.createElement('option');
																														opt.value =valuearr[r];
																														opt.innerHTML = valuearr[r];
																														ParameterAdvancedSearchCombo.appendChild(opt);
																													}
																												});
																												
																												
																												

                                                                                         
                                                                                   </script>
																			</select>
																	</div>
																	<div class="col-sm-3" style="margin-top:10px"> 
																		<select id="EqualToAdvancedSearch" name=""   class="form-control" style="height:" > 
																					 
																					  <option value="">Equal To</option> 
																			
																					 
																		</select>
																	</div>
																	<div class="col-sm-4" style="margin-top:10px">
																		
																			
																			<select id="ParameterAdvancedSearch"  name=""   class="form-control" style="height:">
																				<option value=" "></option>
																			</select>
																			

																		<!--<select id="ParameterAdvancedSearch" name="ParameterAdvancedSearch"  class="form-control" style="height:" > -->
																				  
																				
																			  <?php  
																			     // $json =$RawMaterialTable;
																				// echo $json;
																					 // $koyim = json_decode($json, true);
																					//echo $koyim['0'];
																					// foreach($koyim as $value) {
																						// $ParameterAdvancedSearch = $value['RecID'];
																						
																					   // echo'<pre>';
																					   // print_r( "<option value=\"$ParameterAdvancedSearch\">$ParameterAdvancedSearch</option>");

																						 // echo'</pre>';
																					// }
																				 
																					?>
																				 
																				 
																		
																	</div>
																	<div class="col-sm-1" style="margin-top:10px">
																		<input type="button" value="Apply" class="btn btn-secondary" onclick="AdvancedFetch()">
																	</div>
															</div>		
															

                                                        </div>
                                                      <!--  <div class="modal-footer" style="background-color:">
                                                                <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload();">Close</button>
                                                        </div> -->
                                                </div>
                                            </div>
                                    </div>
                                    </div>
					
					<!-------------------------                   --------------------------------------------->
					
					
				
        </div>
	
	<script type="text/javascript">
      $(".livesearch").chosen();
	 
</script>
	
<script type="text/javascript">
    $(window).on('load',function(){
		
		// alert(document.getElementById("TableRecID").value);
		// alert(document.getElementById("UnitTable").value);
		document.getElementById("blah").style.display="none";
		$('input[type="textbox"]').keyup(function(e) {
			if(e.keyCode == 13) {
				$(this).nextAll(".form-control").eq(0).slideToggle();
				//$(this).next(".form-control").focus();
			}
		});
		
		// alert(document.getElementById("RawMaterialTable").value);
		
      document.getElementById("Modal-PartName").disabled = true;
	  document.getElementById("Modal-HsnCode").disabled = true;
	

				
					document.getElementById("SaveButton").disabled=true;
			
	   $recids=document.getElementById('Modal-StartRecID').value;
																					
																						 document.getElementById('Modal-RecID').value=$recids;
																																							
																				console.log('fetchResult'+$recids);
																			   $.ajax({
																					type :"POST",
																				   data : {RecID : $recids},
																				   url  :"Fetch.php",
																				   dataType : "json",
																				   encode : true,
																				   success : function(jsondata){
																					
																					  $.each(jsondata, function(key, val) {
																						  if(val!=null)
																						  {
																							document.getElementById("Modal-"+key).value=val.toString().trim();
																							 // var sel = document.getElementById('scripts');
																								
																							
																							 
																							
																						  }
																					});
																			
																				   }
																			   });
    });
	
	

		<!-----     Image Upload  -------------->
		
		
		 function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
					document.getElementById("ImageOnLoad").style.display="none";
					document.getElementById("blah").style.display="block";
					// document.getElementById("FileImage").style.display="none";
                    $('#blah')
                        .attr('src', e.target.result)
                        .width(200)
                        .height(240);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }



		function PreviousFunction()
		{
			 $recids=document.getElementById('Modal-StartRecID').value;
			
			
																					$MaxRecID=document.getElementById('Modal-StartRecID').value;
																						$CountMaxRecID=document.getElementById('CountMaxRecID').value;
																					$RMJson=document.getElementById('TableRecID').value;
																												var arr = JSON.parse($RMJson);
																												
																// alert($RMJson);
																	
																																								
																					// $SelectedFilter="RecID";							
																					
																		
																					for(i=$MaxRecID-1;i<$CountMaxRecID;i--)
																					{
																						
																						
																							  for(j=0;j<=$CountMaxRecID;j++)
																							  {
																								 var obj = arr[j];	
																									for (var key in obj)
																									{
																										
																										value=obj[key];
																										if(value==i)
																										{
																											break;
																										}
																										
																									}
																									if(value==i)
																										{
																											break;
																										}
																							  }
																							  if(value==i)
																										{
																											break;
																										}
																								else if (i==0)
																								{
																									
																									value=$MaxRecID;
																									break;
																								}
																					}
																					
																					
																			
																							
																							 $recids=value;
																							 // if($recids!=0)
																							 // {
																								// document.getElementById('CountChange').innerHTML=$recids;
																							 // }	

																						
																				console.log('fetchResult'+$recids);
																			   $.ajax({
																					type :"POST",
																				   data : {RecID : $recids},
																				   url  :"Fetch.php",
																				   dataType : "json",
																				   encode : true,
																				   success : function(jsondata){
																					    $command = jsondata['command'];
																					   $FetchRecID = jsondata['RecID'];
																					  $.each(jsondata, function(key, val) {
																						  if(val!=null)
																						  {
																							document.getElementById("Modal-"+key).value=val.toString().trim();
																							document.getElementById('Modal-StartRecID').value=$FetchRecID;
																						  }
																					});
																			
																				   }
																			   });
		}
		function NextFunction()
		{
			$recids=document.getElementById('Modal-StartRecID').value;
			$CountMaxRec=document.getElementById("CountMaxRecID").value;
																					$RMJson=document.getElementById('TableRecID').value;
																												var arr = JSON.parse($RMJson);			
																						
																						
																						for(i=++$recids;i<=$CountMaxRec;i++)
																					{
																						
																						
																							  for(j=0;j<$CountMaxRec;j++)
																							  {
																								 var obj = arr[j];	
																									for (var key in obj)
																									{
																										
																										value=obj[key];
																										if(value==i)
																										{
																											break;
																										}
																										
																									}
																									if(value==i)
																										{
																											break;
																										}
																							  }
																							  if(value==i)
																										{
																											break;
																										}
																								
																					}			
																							$recids=value;
																							
																						 // document.getElementById('Modal-RecID').value=$recids;
																						// $y="1";
																						// $recids=++$recids;	
																																					
																						// if($recids<=$CountMaxRec)
																						// {
																						 // document.getElementById('CountChange').innerHTML=$recids;
																						// }
																				console.log('fetchResult'+$recids);
																			   $.ajax({
																					type :"POST",
																				   data : {RecID : $recids},
																				   url  :"Fetch.php",
																				   dataType : "json",
																				   encode : true,
																				   success : function(jsondata){
																					    $command = jsondata['command'];
																					   $FetchRecID = jsondata['RecID'];
																					  $.each(jsondata, function(key, val) {
																						  if(val!=null)
																						  {
																							document.getElementById("Modal-"+key).value=val.toString().trim();
																							document.getElementById('Modal-StartRecID').value=$FetchRecID;
																						  }
																					});
																			
																				   }
																			   });
		}
			function AdvancedFetch()
				{
					
					$PartyAdvancedSearch = document.getElementById('PartyAdvancedSearch');	
																												$SelectedFilter=$PartyAdvancedSearch.options[$PartyAdvancedSearch.selectedIndex].text
																												
					$ParameterAdvancedSearch = document.getElementById('ParameterAdvancedSearch');	
					$SelectedFilterFetch=$ParameterAdvancedSearch.options[$ParameterAdvancedSearch.selectedIndex].text
					$RMJson=document.getElementById('RawMaterialTable').value;
																												var arr = JSON.parse($RMJson);
																												document.getElementById("ParameterAdvancedSearch")
                                                                                                                  .innerHTML="";
																												  
																												  
																												  var selarr=[];
																												  var selkeys = ['PartName','PartNo','MaterialType','Description','PPCName','RecID'];
																												  var j=0;
																												for (var i = 0; i < arr.length; i++){
																												  // document.write("<br><br>array index: " + i);
																												  var isSel=0;
																												  var obj = arr[i];
																												  
																												  for (var key in obj){
																													  if(key==$SelectedFilter && obj[key]==$SelectedFilterFetch)
																													  {
																															selarr[j++]= _.pick(arr[i],selkeys);
																															//isSel=1;	
																															//selarr[i][key]=obj[i];
																															//arr.splice(i,1);
																															//selarr[j++]=arr[i];
																													  }
																												  }
																												  // if(isSel==1)
																												  // {
																													  // for (var key in obj){
																														  // selarr[j]=[];
																														  // if(selkeys.includes(key))
																														  // {
																																// selarr[j++][key]=obj[i];
																																//arr.splice(i,1);
																																//selarr[j++]=arr[i];
																														  // }
																													  // }
																												  // }
																												  
																												}
																											document.getElementById('FindTable').innerHTML="";	
																											constructTable("#FindTable",selarr,1)    	
				}
	

		function getRowOnClick(clicktype,jsondatarow)
		{
			if(clicktype==1)//FindTable
			{
				return 'FindDetails("'+jsondatarow['RecID']+'")';
			}
			if(clicktype==2)//Section
			{
				return 'ModaltoggleSection("'+jsondatarow['Section']+'")';
			}
		}
		function constructTable(tableid,jsondata,clicktype) { 
            var cols = Headers(jsondata, tableid);
            for (var i = 0; i < jsondata.length; i++) { 
				//$RecID='1'
                var row = $('<tr/>');
				row.attr('style','text-align:center;vertical-align:middle;font-weight:normal;'); 
				row.attr('onclick',getRowOnClick(clicktype,jsondata[i])); 
                for (var colIndex = 0; colIndex < cols.length; colIndex++) 
                { 
                    var val = jsondata[i][cols[colIndex]];                
                    if (val == null) val = "";   
                        row.append($('<td/>').html(val)); 
                } 
                $(tableid).append(row); 
            } 
        } 
        function constructTableWithoutHeaders(tableid,jsondata) { 
            var cols = HeadersWithoutPrint(jsondata, tableid);
            for (var i = 0; i < jsondata.length; i++) { 
                var row = $('<tr/>');    
                for (var colIndex = 0; colIndex < cols.length; colIndex++) 
                { 
                    var val = jsondata[i][cols[colIndex]];                
                    if (val == null) val = "";   
                        row.append($('<td/>').html(val)); 
                } 
                $(tableid).append(row); 
            } 
        } 
    
        function HeadersWithoutPrint(list, tableid) { 
            var columns = []; 
            var header = $('<tr/>');  
            for (var i = 0; i < list.length; i++) { 
                var row = list[i]; 
                for (var k in row) { 
                    if ($.inArray(k, columns) == -1) { 
                        columns.push(k);  
						var thead = $('<th/>').html(k);
						thead.attr('style','box-shadow: 1px 1px 2px 1px lightgray;padding:4px;text-align:center;vertical-align:middle;background: #6c7ae0;color:white;font-weight: normal;width:20px;'); 
                        header.append(thead); 
                    } 
                } 
            } 
            //$(tableid).append(header); 
                return columns; 
        }
		function Headers(list, tableid) { 
            var columns = []; 
            var header = $('<tr/>');  
            for (var i = 0; i < list.length; i++) { 
                var row = list[i]; 
                for (var k in row) { 
                    if ($.inArray(k, columns) == -1) { 
                        columns.push(k);  
                        var thead = $('<th/>').html(k);
						thead.attr('style','box-shadow: 1px 1px 2px 1px lightgray;padding:4px;text-align:center;vertical-align:middle;background: #6c7ae0;color:white;font-weight: normal;width:20px;'); 
						header.append(thead); 
                    } 
                } 
            } 
            $(tableid).append(header); 
                return columns; 
        }                       

				// Part No Change 
  
$('#Modal-PartNo').change(function ()
{
			$PartName=document.getElementById('Modal-PartName').value;
			$PartNo=document.getElementById('Modal-PartNo').value;
			document.getElementById('Modal-PPCName').value=$PartName+':'+$PartNo
			document.getElementById('Modal-Description').value=$PartName+' ('+$PartNo+')'
});

		//Net Wt Change
		
		$('#Modal-NetWt').change(function ()
{
			$NetWt=document.getElementById('Modal-NetWt').value;
			if($NetWt==0)
			{
				
				alert("Net Weight Of The Product CanNot Be 0");
					    document.getElementById("Modal-NetWt").focus();
					 document.getElementById("Modal-NetWt").value="";
				return false;
			}
			
			
});

function NetWtValidation()
{	
		$NetWt=document.getElementById('Modal-NetWt').value;
			if($NetWt==0)
			{
				alert("Net Weight Of The Product CanNot Be 0");
					    document.getElementById("Modal-NetWt").focus();
				return false;
			}
}

			function SectionInsertOpen()
			{
				$('#SectionInsertModal').modal('toggle');
			
			}
			
			function ModaltoggleSection($ParmValue)
			
			{
				
				document.getElementById('Modaltoggle-Section').value=$ParmValue;
				$('#SectionModal').modal('hide');
					document.getElementById('Modaltoggle-Thickness').focus;
				
			}


$(document).ready(function(){
    $("#SectionInsertModal").on('shown.bs.modal', function(){
        $(this).find('#SectionModal-Section').focus();
    });
});


	
	function SectionOpen()
	{
		$recids=1;
		 LeadDetailsAjax($recids);
		 document.getElementById("SectionTable").innerHTML="";
		$('#SectionModal').modal('toggle');
		$("#SectionModal").on('shown.bs.modal', function () {
			$(this).find("#SectionTableSearch").focus();
			});
				
				
	}
	function LeadDetailsAjax($recids)
        {
            $.ajax({
               type :"POST",
               data : {RecID : $recids},
               url  :"SectionTable.php",
               dataType : "json",
               encode : true,
               success : function(jsondata){
                   document.getElementById("leadDetailsinfo-table").innerHTML="";
                   constructTable("#leadDetailsinfo-table",jsondata,2)    
               }
            });
        }

	// function SectionInsert()
	// {
			// $('#SectionModal').modal('toggle');
	// }
	
	function SectionUpdate()
	{
		$recids=1;
		 LeadDetailsAjax($recids);
			$SectionModalSection=document.getElementById('SectionModal-Section').value;
		document.getElementById('Modaltoggle-Section').value=$SectionModalSection;
	
	if($SectionModalSection!="")
	{
		$('#SectionInsertModal').modal('hide');
			 $.ajax({
					   type :"POST",
					   data : {SectionModalSection : $SectionModalSection
							 },
					   url  :"RawMaterialSectionInsert.php",
					   dataType : "json",
					   encode : true,
					   success : function(jsondata){
							 $command = jsondata['command'];
							 if($command==0)
							 {
								 alert("Section Already Exist");
							 }
					   }
					});
					
	}
			else
			{
				alert("Section Is Blank");
			}
	}

		function CloseFind()
		{
			$('#findmodal').modal('hide');
		}	

		function FindDetails($recids)
		{
			$('#findmodal').modal('hide');	
			console.log('fetchResult'+$recids);
																			   $.ajax({
																					type :"POST",
																				   data : {RecID : $recids},
																				   url  :"Fetch.php",
																				   dataType : "json",
																				   encode : true,
																				   success : function(jsondata){
																					    $command = jsondata['command'];
																					   $FetchRecID = jsondata['RecID'];
																					  $.each(jsondata, function(key, val) {
																						  if(val!=null)
																						  {
																							document.getElementById("Modal-"+key).value=val.toString().trim();
																							document.getElementById('Modal-StartRecID').value=$FetchRecID;
																						  }
																					});
																			
																				   }
																			   });
		}


	function DeleteFunction()
					{
						
				$recids=document.getElementById('Modal-StartRecID').value;		
				 var x = confirm("Really want to Delete Record?")			
				 if(x==true)
				 {
					  window.location.reload();
				  $.ajax({
					   type :"POST",
					   data : {RecID : $recids
							 },
					   url  :"RawMaterialDelete.php",
					   dataType : "json",
					   encode : true,
					   success : function(jsondata){
							
					   }
					});
						
				   }	
				}	
					
					
					


											$(document).ready(function() {
												$('#GradeTableSearch').off('keyup');
												$('#GradeTableSearch').on('keyup', function() {
													// Your search term, the value of the input
													var searchTerm = $('#GradeTableSearch').val();
													// table rows, array
													var tr = [];

													// Loop through all TD elements
													$('#GradeTable').find('td').each(function() {
														var value = $(this).html();
														// if value contains searchterm, add these rows to the array
														if (value.toLowerCase().includes(searchTerm.toLowerCase())) {
															tr.push($(this).closest('tr'));
														}
													});

													// If search is empty, show all rows
													if ( searchTerm == '') {
														$('tr').show();
													} else {
														// Else, hide all rows except those added to the array
														$('tr').not('thead tr').hide();
														tr.forEach(function(el) {
															el.show();
														});
													}
												});
											});
				
											$(document).ready(function() {
												$('#HsnTableSearch').off('keyup');
												$('#HsnTableSearch').on('keyup', function() {
													// Your search term, the value of the input
													var searchTerm = $('#HsnTableSearch').val();
													// table rows, array
													var tr = [];

													// Loop through all TD elements
													$('#HsnTable').find('td').each(function() {
														var value = $(this).html();
														// if value contains searchterm, add these rows to the array
														if (value.toLowerCase().includes(searchTerm.toLowerCase())) {
															tr.push($(this).closest('tr'));
														}
													});

													// If search is empty, show all rows
													if ( searchTerm == '') {
														$('tr').show();
													} else {
														// Else, hide all rows except those added to the array
														$('tr').not('thead tr').hide();
														tr.forEach(function(el) {
															el.show();
														});
													}
												});
											});
						
											$(document).ready(function() {
												$('#SectionTableSearch').off('keyup');
												$('#SectionTableSearch').on('keyup', function() {
													// Your search term, the value of the input
													var searchTerm = $('#SectionTableSearch').val();
													// table rows, array
													var tr = [];

													// Loop through all TD elements
													$('#leadDetailsinfo-table').find('td').each(function() {
														var value = $(this).html();
														// if value contains searchterm, add these rows to the array
														if (value.toLowerCase().includes(searchTerm.toLowerCase())) {
															tr.push($(this).closest('tr'));
														}
													});

													// If search is empty, show all rows
													if ( searchTerm == '') {
														$('tr').show();
													} else {
														// Else, hide all rows except those added to the array
														$('tr').not('thead tr').hide();
														tr.forEach(function(el) {
															el.show();
														});
													}
												});
											});
		
// $('#Modal-MaterialType').change(function () {
	
	
				// $MaterialValidation = document.getElementById("Modal-MaterialType").value;
					// if ($MaterialValidation=='CTL' || $MaterialValidation=='Bar' || $MaterialValidation=='Rod' )
					// {
						// document.getElementById("LengthHide").style.display="block";
						// document.getElementById("ModalToggleCheckBox").style.display="block";
						// document.getElementById("Modaltoggle-Shape").selectedIndex = "0";						
						// document.getElementById("Modal-Unit").value="Nos";
						// document.getElementById("Modal-Unit").disabled=true;
						// setDefaultConsUnit("KGS");
						// $Modal-ConsUnit.options[$Modal-ConsUnit.selectedIndex].text
						// document.getElementById("Modal-ConsUnit").innerHTML="kgs";
						// document.getElementById("Modal-PartName").disabled=true;
						// document.getElementById("Modal-PartNo").disabled=true;
						// document.getElementById("Modaltoggle-ToleranceType").value="+";
						// document.getElementById("Modaltoggle-Thickness").value="0";
						// document.getElementById("Modaltoggle-Width").value="0";document.getElementById("Modaltoggle-Length").value="0";
						// document.getElementById("Modaltoggle-Grade").value=" ";
						// document.getElementById("Modal-TD").value="true";
						// document.getElementById("Modaltoggle-VarLength").value=" ";
						// $('#Modal-AllowBom').attr('checked',false);
						
					// }	
					
					// else if($MaterialValidation == 'CutLength')
					// {		
							// document.getElementById("Modaltoggle-Shape").selectedIndex = "0";
							// document.getElementById("Modal-Unit").value="Nos"; document.getElementById("Modal-Unit").disabled=true;
							
						// document.getElementById("LengthHide").style.display="none";
						// document.getElementById("ModalToggleCheckBox").style.display="none";
						// document.getElementById("Modal-PartName").disabled=true;
						// document.getElementById("Modal-PartNo").disabled=true;
						// document.getElementById("Modaltoggle-ToleranceType").value="+";
						// document.getElementById("Modaltoggle-Thickness").value="0";
						// document.getElementById("Modaltoggle-Width").value="0";document.getElementById("Modaltoggle-Length").value="0";
						// document.getElementById("Modaltoggle-Grade").value=" ";
						// document.getElementById("Modal-TD").value="true";
						// document.getElementById("Modaltoggle-VarLength").value=" ";
						// setDefaultConsUnit("KGS");
					// }
					
					// else if($MaterialValidation == 'Coil')
					// {
							// document.getElementById("LengthHide").style.display="block";
						// document.getElementById("ModalToggleCheckBox").style.display="block";
						// document.getElementById("Modaltoggle-Shape").selectedIndex = "2";
							// document.getElementById("Modal-Unit").value="kgs"; document.getElementById("Modal-Unit").disabled=false;
						// setDefaultConsUnit("KGS");
						// document.getElementById("Modal-PartName").disabled=true;
						// document.getElementById("Modal-PartNo").disabled=true;
						// document.getElementById("Modaltoggle-ToleranceType").value="+";
						// document.getElementById("Modaltoggle-Thickness").value="0";
						// document.getElementById("Modaltoggle-Width").value="0";document.getElementById("Modaltoggle-Length").value="0";
						// document.getElementById("Modaltoggle-Grade").value=" ";
						// document.getElementById("Modal-TD").value="true";
						// document.getElementById("Modaltoggle-VarLength").value=" ";
						// $('#Modal-AllowBom').attr('checked',false);
					// }
					
					// else if($MaterialValidation == 'Sheet' || $MaterialValidation == 'Strip' || $MaterialValidation == 'Blank')
					// {
						// document.getElementById("LengthHide").style.display="block";
						// document.getElementById("ModalToggleCheckBox").style.display="block";	
						// document.getElementById("Modaltoggle-Shape").selectedIndex = "2";
						// document.getElementById("Modal-Unit").value="Nos"; document.getElementById("Modal-Unit").disabled=true;
						// setDefaultConsUnit("KGS");
						// document.getElementById("Modaltoggle-ToleranceType").value="+";
						// document.getElementById("Modal-PartName").disabled=true;
						// document.getElementById("Modal-PartNo").disabled=true;
						// document.getElementById("Modaltoggle-Thickness").value="0";
						// document.getElementById("Modaltoggle-Width").value="0";document.getElementById("Modaltoggle-Length").value="0";
						// document.getElementById("Modaltoggle-Grade").value=" ";
						// document.getElementById("Modal-TD").value="true";
						// document.getElementById("Modaltoggle-VarLength").value=" ";
						// $('#Modal-AllowBom').attr('checked',false);
					// }
					
					// else if($MaterialValidation == 'Tube' || $MaterialValidation == 'Pipe')
					// {
						// document.getElementById("LengthHide").style.display="block";
						// document.getElementById("ModalToggleCheckBox").style.display="block";
						// document.getElementById("Modaltoggle-Shape").selectedIndex = "0";
						// document.getElementById("Modal-Unit").value="Kgs"; document.getElementById("Modal-Unit").disabled=true;
					// setDefaultConsUnit("KGS");
						// document.getElementById("Modaltoggle-ToleranceType").value="+";
						// document.getElementById("Modaltoggle-Thickness").value="0";
						// document.getElementById("Modaltoggle-Width").value="0";document.getElementById("Modaltoggle-Length").value="0";
						// document.getElementById("Modaltoggle-Grade").value=" ";
						// document.getElementById("Modal-TD").value="true";
						// document.getElementById("Modaltoggle-VarLength").value=" ";
						// $('#Modal-AllowBom').attr('checked',false);
					// }
					// else if($MaterialValidation == 'Scrap (Commercial)' || $MaterialValidation == 'Scrap (Wastage)')
					// {
						// document.getElementById("LengthHide").style.display="block";
						// document.getElementById("ModalToggleCheckBox").style.display="block";
						// document.getElementById("Modaltoggle-Shape").selectedIndex = "2";
						// document.getElementById("Modal-Unit").value="Kgs"; document.getElementById("Modal-Unit").disabled=true;
					// setDefaultConsUnit("KGS");
						// document.getElementById("Modal-PartName").disabled=false;
						// document.getElementById("Modal-PartNo").disabled=false;
						// document.getElementById("Modaltoggle-Thickness").value="0";
						// document.getElementById("Modaltoggle-Width").value="0";document.getElementById("Modaltoggle-Length").value="0";document.getElementById("Modaltoggle-ToleranceType").value="+";
						// document.getElementById("Modaltoggle-Grade").value=" ";
						// document.getElementById("Modal-TD").value="false";
						// document.getElementById("Modaltoggle-VarLength").value=" ";
					// }
					// else if($MaterialValidation == 'Ferrite Core')
					// {
						// document.getElementById("LengthHide").style.display="block";
						// document.getElementById("ModalToggleCheckBox").style.display="block";
						// document.getElementById("Modaltoggle-Shape").selectedIndex = "2";
						// document.getElementById("Modal-Unit").value="Nos"; document.getElementById("Modal-Unit").disabled=true;
						// document.getElementById("Modal-PartName").disabled=false;
						// document.getElementById("Modal-PartNo").disabled=false;
						// document.getElementById("Modaltoggle-Thickness").value="0";
					// setDefaultConsUnit("NOS");
						// document.getElementById("Modaltoggle-Width").value="0";document.getElementById("Modaltoggle-Length").value="0";document.getElementById("Modaltoggle-ToleranceType").value="+";
						// document.getElementById("Modaltoggle-Grade").value=" ";
						// document.getElementById("Modal-TD").value="false";
						// document.getElementById("Modaltoggle-VarLength").value=" ";
						// $('#Modal-AllowBom').attr('checked',false);
					// }
					// else if($MaterialValidation == 'Wire')
					// {
						// document.getElementById("LengthHide").style.display="block";
						// document.getElementById("ModalToggleCheckBox").style.display="block";
						// document.getElementById("Modaltoggle-Shape").selectedIndex = "3";
						// document.getElementById("Modal-Unit").value="NOS"; document.getElementById("Modal-Unit").disabled=true;
						// document.getElementById("Modal-PartName").disabled=true;
						// document.getElementById("Modal-PartNo").disabled=true;
					// setDefaultConsUnit("KGS");
						// document.getElementById("Modaltoggle-Thickness").value="0";
						// document.getElementById("Modaltoggle-Width").value="0";document.getElementById("Modaltoggle-Length").value="0";document.getElementById("Modaltoggle-ToleranceType").value="+";
						// document.getElementById("Modaltoggle-Grade").value=" ";
						// document.getElementById("Modal-TD").value="true";
						// document.getElementById("Modaltoggle-VarLength").value="True";
						// $('#Modal-AllowBom').attr('checked',false);
					// }
					// else 
					// {
								// document.getElementById("Modaltoggle-Shape").selectedIndex = "0";	
						// document.getElementById("Modal-PartName").disabled=false;
						// document.getElementById("Modal-PartNo").disabled=false;
						// document.getElementById("Modal-Unit").value="KGS"; document.getElementById("Modal-Unit").disabled=false;
				// setDefaultConsUnit("KGS");
						// document.getElementById("Modal-Description").disabled=false;
						// document.getElementById("Modaltoggle-Grade").value="N.A";
						// document.getElementById("Modaltoggle-Thickness").value="0";
						// document.getElementById("Modaltoggle-Width").value="0";document.getElementById("Modaltoggle-Length").value="0";document.getElementById("Modaltoggle-ToleranceType").value="N.A";
						// document.getElementById("Modal-TD").value="false";

						// document.getElementById("Modaltoggle-VarLength").value=" ";
						// $('#Modal-AllowBom').attr('checked',false);
						
						
					// }
		// });
		function setDefaultConsUnit(ConsUnit)
		{	
		 	var listbox= document.getElementById("Modal-ConsUnit");
			
							var searchtext = ConsUnit;
				for (var i = 0; i < listbox.options.length; ++i) {
					if (listbox.options[i].text === searchtext) listbox.options[i].selected = true;
}
		}
		





	
	
	

	
	<!------------------------           Edit Details Fetch Start                            --------------------------->	
								  function fetchResult(){
																		  if(document.getElementById("EditButton").value=="Edit")
																			  {			
																					  document.getElementById("SaveButton").disabled = false;
																					document.getElementById("EditButton").value="Cancel Edit";
																					// document.getElementById("Modal-MaterialType").disabled = false;
																					document.getElementById("Modal-PartName").disabled = false;
																					document.getElementById("Modal-PartNo").disabled = false;
																					document.getElementById("Modal-PPCName").disabled = false;
																					document.getElementById("Modal-Description").disabled = false;
																					document.getElementById("Modal-StockLocation").disabled = false;
																					// document.getElementById("Modal-ConsUnit").disabled = false;
																					document.getElementById("Modal-HsnCode").disabled = false;
																					document.getElementById("Modal-TaxPer").disabled = false;
																					document.getElementById("Modal-Unit").disabled = false;	
																					document.getElementById("Modal-NetWt").disabled = false;
																					document.getElementById("Modal-NetWtUnit").disabled = false;
																					document.getElementById("Modal-MinStockLevel").disabled = false;
																					document.getElementById("Modal-Gwt").disabled = false;
																					document.getElementById("Modal-GwtUnit").disabled = false;
																					document.getElementById("Modal-MaxStockLevel").disabled = false;
																					document.getElementById("Modal-ScrapWt").disabled = false;
																					document.getElementById("Modal-ScrapWtUnit").disabled = false;
																					document.getElementById("Modal-ReorderStockLevel").disabled = false;
																					document.getElementById("Modal-ProductType").disabled = false;																										
																				 }
																				else
																				{
																						document.getElementById("EditButton").value="Edit";
																						document.getElementById("SaveButton").disabled = true;
																						// document.getElementById("Modal-MaterialType").disabled = true;
																						document.getElementById("Modal-PartName").disabled = true;
																						document.getElementById("Modal-PartNo").disabled = true;
																						document.getElementById("Modal-PPCName").disabled = true;
																						document.getElementById("Modal-Description").disabled = true;
																						document.getElementById("Modal-StockLocation").disabled = true;
																						// document.getElementById("Modal-ConsUnit").disabled = true;
																						document.getElementById("Modal-HsnCode").disabled = true;
																						document.getElementById("Modal-TaxPer").disabled = true;
																						document.getElementById("Modal-Unit").disabled = true;
																						document.getElementById("Modal-NetWt").disabled = true;
																						document.getElementById("Modal-NetWtUnit").disabled = true;
																						document.getElementById("Modal-MinStockLevel").disabled = true;
																						document.getElementById("Modal-Gwt").disabled = true;
																						document.getElementById("Modal-GwtUnit").disabled = true;
																						document.getElementById("Modal-MaxStockLevel").disabled = true;
																						document.getElementById("Modal-ScrapWt").disabled = true;
																						document.getElementById("Modal-ScrapWtUnit").disabled = true;
																						document.getElementById("Modal-ReorderStockLevel").disabled = true;
																						document.getElementById("Modal-ProductType").disabled = true;																										
																				}
																								
																					
																						 
																						 $recids=document.getElementById('Modal-StartRecID').value;
																						 document.getElementById('Modal-Mode').value="Edit";
																						 document.getElementById('Modal-RecID').value=$recids;
																																							
																				console.log('fetchResult'+$recids);
																			   $.ajax({
																					type :"POST",
																				   data : {RecID : $recids},
																				   url  :"Fetch.php",
																				   dataType : "json",
																				   encode : true,
																				   success : function(jsondata){
																					   $command = jsondata['command'];
																					   $FetchRecID = jsondata['RecID'];
																					  $.each(jsondata, function(key, val) {
																						  if(val!=null)
																						  {
																							document.getElementById("Modal-"+key).value=val.toString().trim();
																							
																						  }
																					});
																			
																				   }
																			   });
												}	
							<!------------------------           Edit Details Fetch Close                            --------------------------->			
	
// function GradeOpen()
// {
			
	    // $("#grademodal").modal('toggle');

// $("#grademodal").on('shown.bs.modal', function () {
    // $(this).find("#GradeTableSearch").focus();
// });
// }
// function HsnOpen()
// {

	    // $("#hsnmodal").modal('toggle');
		 

// $("#hsnmodal").on('shown.bs.modal', function () {
    // $(this).find("#HsnTableSearch").focus();
// });

// }

// function GradeTableDetails($Material,$Grade)
// {
	  // $("#grademodal").modal('hide');
	 // document.getElementById("Modaltoggle-Grade").value=$Grade;
	  // document.getElementById("Modaltoggle-Material").value=$Material;
	  // document.getElementById("Modaltoggle-Shape").focus();
	
// }
// function HsnTableDetails($HsnCode,$TaxPer)
// {
	  // $("#hsnmodal").modal('hide');
	 // document.getElementById("Modal-HsnCode").value=$HsnCode;
	  // document.getElementById("Modal-TaxPer").value=$TaxPer;
	  // document.getElementById("Modal-TaxPer").disabled=true;
	
// }
// function FindFunction()

	 
		
	function Enable() {
	


      // $(window).scrollTop($('#Modal-ConsUnit').position().top); 



		document.getElementById("SaveButton").disabled=false;
// document.getElementById("Modal-MaterialType").disabled = false;
document.getElementById("Modal-PartName").disabled = false;
document.getElementById("Modal-PartNo").disabled = false;
document.getElementById("Modal-PPCName").disabled = false;
document.getElementById("Modal-Description").disabled = false;
document.getElementById("Modal-StockLocation").disabled = false;
// document.getElementById("Modal-ConsUnit").disabled = false;
document.getElementById("Modal-HsnCode").disabled = false;
document.getElementById("Modal-TaxPer").disabled = false;
document.getElementById("Modal-Unit").disabled = false;
document.getElementById("Modal-NetWt").disabled = false;
document.getElementById("Modal-NetWtUnit").disabled = false;
document.getElementById("Modal-MinStockLevel").disabled = false;
document.getElementById("Modal-Gwt").disabled = false;
document.getElementById("Modal-GwtUnit").disabled = false;
document.getElementById("Modal-MaxStockLevel").disabled = false;
document.getElementById("Modal-ScrapWt").disabled = false;
document.getElementById("Modal-ScrapWtUnit").disabled = false;
document.getElementById("Modal-ReorderStockLevel").disabled = false;
document.getElementById("Modal-ProductType").disabled = false;
  var PartName=document.getElementById("hsntable").value;
   document.getElementById("Modal-PartName").focus();
  

 
  
  if(document.getElementById("AddStartButton").value=="Add")
  {
		document.getElementById("AddStartButton").value="Cancel Add";
					// document.getElementById("Modal-MaterialType").value = " ";
			document.getElementById("Modal-PartName").value = " ";
			document.getElementById("Modal-PartNo").value =  " ";
			document.getElementById("Modal-PPCName").value =  " ";
			document.getElementById("Modal-Description").value =  " ";
			document.getElementById("Modal-StockLocation").value =  " ";
			// document.getElementById("Modal-ConsUnit").value =  " ";
			document.getElementById("Modal-HsnCode").value =  " ";
			document.getElementById("Modal-TaxPer").value =  " ";
			document.getElementById("Modal-Unit").value =  " ";
			  document.getElementById("Modal-StockLocation").value="Store Floor";
			  document.getElementById("FindButton").disabled = true;
			  document.getElementById("EditButton").disabled = true;
			  document.getElementById("DeleteButton").disabled = true;
  }
	else
	{
		document.getElementById("AddStartButton").value="Add";
		document.getElementById("SaveButton").disabled=true;
// document.getElementById("Modal-MaterialType").disabled = true;
document.getElementById("Modal-PartName").disabled = true;
document.getElementById("Modal-PartNo").disabled = true;
document.getElementById("Modal-PPCName").disabled = true;
document.getElementById("Modal-Description").disabled = true;
document.getElementById("Modal-StockLocation").disabled = true;
// document.getElementById("Modal-ConsUnit").disabled = true;
document.getElementById("Modal-HsnCode").disabled = true;
document.getElementById("Modal-TaxPer").disabled = true;
document.getElementById("Modal-Unit").disabled = true;
document.getElementById("Modal-NetWt").disabled = true;
document.getElementById("Modal-NetWtUnit").disabled = true;
document.getElementById("Modal-MinStockLevel").disabled = true;
document.getElementById("Modal-Gwt").disabled = true;
document.getElementById("Modal-GwtUnit").disabled = true;
document.getElementById("Modal-MaxStockLevel").disabled = true;
document.getElementById("Modal-ScrapWt").disabled = true;
document.getElementById("Modal-ScrapWtUnit").disabled = true;
document.getElementById("Modal-ReorderStockLevel").disabled = true;
document.getElementById("Modal-ProductType").disabled = true;

 document.getElementById("FindButton").disabled = false;
			  document.getElementById("EditButton").disabled = false;
			  document.getElementById("DeleteButton").disabled = false;
		
		
											document.getElementById("Modal-StockLocation").value="Store Floor";
											document.getElementById("AddStartButton").value="Add";
											   $recids=document.getElementById('Modal-StartRecID').value;
																					
																						 document.getElementById('Modal-RecID').value=$recids;
																																							
																				console.log('fetchResult'+$recids);
																			   $.ajax({
																					type :"POST",
																				   data : {RecID : $recids},
																				   url  :"Fetch.php",
																				   dataType : "json",
																				   encode : true,
																				   success : function(jsondata){
																					  
																					  $.each(jsondata, function(key, val) {
																						  if(val!=null)
																						  {
																							document.getElementById("Modal-"+key).value=val.toString().trim();
																							
																						  }
																					});
																			
																				   }
																			   });
		
	}	
	
	
}

function EditAgentDetails()
{
	  if(document.getElementById("EditButton").value=="Edit")
  {
	  document.getElementById("EditButton").value="Cancel Edit";
  }
	else
	{
		document.getElementById("EditButton").value="Edit";
	}
}
	
	
function UpdateAgentDetails(){
	
				// $ModalShapeValidation = document.getElementById('Modaltoggle-Shape');	
				$SelectedFilter=$ModalShapeValidation.options[$ModalShapeValidation.selectedIndex].text
				
				$AddStartButton = document.getElementById("AddStartButton").value;
				$Mode = document.getElementById("Modal-Mode").value;
				
                // $MaterialType = document.getElementById("Modal-MaterialType").value;
                $PartName = document.getElementById("Modal-PartName").value;
                $PartNo = document.getElementById("Modal-PartNo").value;
                $PPCName = document.getElementById("Modal-PPCName").value;
                $Description = document.getElementById("Modal-Description").value;
                $Unit = document.getElementById("Modal-Unit").value;
                $StockLocation = document.getElementById("Modal-StockLocation").value;
                $ConsUnit = document.getElementById("Modal-ConsUnit").value;
				$HsnCode = document.getElementById("Modal-HsnCode").value;
				$TaxPer = document.getElementById("Modal-TaxPer").value;
				$Material = document.getElementById("Modaltoggle-Material").value;
				$Grade = document.getElementById("Modaltoggle-Grade").value;
				$Shape = $SelectedFilter;
				$Section= document.getElementById("Modaltoggle-Section").value;
				$Thickness = document.getElementById("Modaltoggle-Thickness").value;	
				$Width = document.getElementById("Modaltoggle-Width").value;
				$Length = document.getElementById("Modaltoggle-Length").value;
				$Tolerance = document.getElementById("Modaltoggle-Tolerance").value;
				$ToleranceType = document.getElementById("Modaltoggle-ToleranceType").value;
				$VarLength = document.getElementById("Modaltoggle-VarLength").value;
				$ModalTD = document.getElementById("Modal-TD").value;
				$GradeID = document.getElementById("Modaltoggle-GradeID").value;
				$ModalAllowBom = document.getElementById("Modal-AllowBom").value;
			
				
				if(document.getElementById("Modal-AllowBom").checked)
					{
						$ModalAllowBom=1;
					}
			else
				{
					$ModalAllowBom=0;
				}	
				
				
				if($AddStartButton=="Cancel Add")
				{
					$ModalRecID =" ";
				}
				else
				{
					$ModalRecID = document.getElementById("Modal-RecID").value;
				}
				
				if($PartName == " ")
				{
					alert("Part Name Can Not Blank");
					return false;
				}
				if($PartNo ==" ")
				{
					alert("Part No Can Not Blank");
					return false;
				}
				if($PPCName ==" ")
				{
					alert("PPCName Can Not Blank");
					return false;
				}
				if($Description ==" ")
				{
					alert("Description Is Blank");
					return false;
					
				}if($Unit ==" ")
				{
					alert("Unit Is Blank");
					return false;
					
				}if($StockLocation ==" ")
				{
					alert("Stock Location Is Blank");
					return false;
					
				}
				if($HsnCode ==" ")	
				{
					alert("HsnCode Is Blank");
					return false;
					
				}
						
						if($StockLocation ==" ")
				{
					alert("TaxPer Is Blank");
					return false;
					
				}
				
				
			
                 
				
				  $.ajax({
               type :"POST",
               data : {ModalRecID : $ModalRecID,
					  Mode : $Mode,
					  
                      PartName : $PartName,
                      PartNo: $PartNo,
                      PPCName : $PPCName,
                      Description : $Description,
                      Unit : $Unit,
                      StockLocation : $StockLocation,
                      ConsUnit : $ConsUnit,
					  HsnCode : $HsnCode,
					  TaxPer : $TaxPer,
					   Material : $Material,
                      Grade : $Grade,
                      Shape : $Shape,
                      Section : $Section,
                      Thickness : $Thickness,
					  Width : $Width,
					  Length : $Length,
					  Tolerance : $Tolerance,
                      ToleranceType : $ToleranceType,
                      VarLength : $VarLength,
					  ModalTD : $ModalTD,
					  GradeID : $GradeID,
					  ModalAllowBom : $ModalAllowBom},
               url  :"RawMaterialSave.php",
               dataType : "json",
               encode : true,
               success : function(jsondata){
					 $Command = jsondata['command'];
					 $JsonPartNo = jsondata['PartNo'];
				 $JsonPPCName = jsondata['PPCName'];
				 $JsonDescription = jsondata['JsonDescription'];
											if($JsonPartNo==0)
										  {
											  alert("PartNo Already Exist");
											  return false;
										  }
										else  if($JsonPPCName==0)
										  {
											  alert("PPCName Already Exist");
											  return false;
											  
										  }
										else  if($JsonDescription==0)
										  {
											  alert("Description Already Exist");
											  return false;
											 
										  }
										
                                            window.location.reload();
                                                
											
               }
            });
                
            }
</script>
		</body>

</html>