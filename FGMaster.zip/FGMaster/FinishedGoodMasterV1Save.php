<?php
        require("Db.php");
            $options = array(  "UID" => $username,  "PWD" => $PWD ,  "Database" =>$Database );
            $conn = sqlsrv_connect($serverName, $options);
			$ModalRecID = $_POST['ModalRecID'];
			$Mode = $_POST['Mode'];
          
            $PartName = $_POST['PartName'];
            $PartNo = $_POST['PartNo'];
            $PPCName = $_POST['PPCName'];
            $Description = $_POST['Description'];
            $Unit = $_POST['Unit'];
            $StockLocation = $_POST['StockLocation'];
            $ProductType = $_POST['ProductType'];
			$HsnCode = $_POST['HsnCode'];
			$TaxPer = $_POST['TaxPer'];
			$NetWt = $_POST['NetWt'];
            $GrossWt = $_POST['GrossWt'];
            $ScrapWt = $_POST['ScrapWt'];
            $NetWtUnit = $_POST['NetWtUnit'];
            $GrossWtUnit = $_POST['GrossWtUnit'];
			$ScrapWtUnit = $_POST['ScrapWtUnit'];
			$MinStockLevel = $_POST['MinStockLevel'];
			$MaxStockLevel = $_POST['MaxStockLevel'];
            $ReorderStockLevel = $_POST['ReorderStockLevel'];
			 $Photo = $_POST['Photo'];
          
			
            $str = "EmsNet_Proc_FinishedGoodMasterV1Web_Save 
					@ModalRecID='".$ModalRecID."',
					@Mode='".$Mode."',
                    @PartName ='".$PartName."',
                @PartNo ='".$PartNo."',
                @PPCName ='".$PPCName."',
                @Description ='".$Description."',
                @Unit ='".$Unit."',
                @StockLocation ='".$StockLocation."',
                @ProductType ='".$ProductType."',
				@HsnCode ='".$HsnCode."',
				@TaxPer ='".$TaxPer."',
				@NetWt ='".$NetWt."',
				@GrossWt ='".$GrossWt."',
                @ScrapWt ='".$ScrapWt."',
                @NetWtUnit ='".$NetWtUnit."',
                @GrossWtUnit ='".$GrossWtUnit."',
                @ScrapWtUnit ='".$ScrapWtUnit."',
                @MinStockLevel ='".$MinStockLevel."',
				@MaxStockLevel ='".$MaxStockLevel."',
				@ReorderStockLevel ='".$ReorderStockLevel."',
				@Photo ='".$Photo."'
				";
             $query = sqlsrv_query($conn,$str);
		
                echo $str;
             
?>